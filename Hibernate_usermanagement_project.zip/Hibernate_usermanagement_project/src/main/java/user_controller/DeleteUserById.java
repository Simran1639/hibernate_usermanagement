package user_controller;

import java.util.Scanner;

import user_Dao.UserDao;

public class DeleteUserById {
	public static void main(String args[]) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter id which you want to delete");
		int id=sc.nextInt();
		
		UserDao dao=new UserDao();
		dao.deleteUser(id);
	}

}
