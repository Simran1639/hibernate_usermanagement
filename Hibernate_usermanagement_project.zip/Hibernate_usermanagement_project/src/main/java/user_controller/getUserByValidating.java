package user_controller;

import java.util.List;
import java.util.Scanner;

import user_Dao.UserDao;
import user_Dto.User;

public class getUserByValidating {

	public static void main(String args[]) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the email....");
		String enail=sc.next();
		System.out.println("enter the password....");
		int pwd=sc.nextInt();
		
		UserDao dao=new UserDao();
		List<User> u=dao.getUserByEmailPwd(enail, pwd);
		
		if(u.size()>0)
		{
			for(User user : u)
			{
				System.out.println("id="+user.getId()+"name="+user.getName()+"email="+user.getEmail()+"address="+user.getAddress());
			}
		}
		else {
			System.out.println("id does not exist.....");
		}
	}
}
