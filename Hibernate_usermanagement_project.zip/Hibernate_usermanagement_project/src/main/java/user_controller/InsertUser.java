package user_controller;

import java.util.Scanner;

import user_Dao.UserDao;
import user_Dto.User;

public class InsertUser {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the name....");
		String name=sc.next();
		System.out.println("enter the email....");
		String email=sc.next();
		System.out.println("enter the password...");
		int pwd=sc.nextInt();
		System.out.println("Enter the address...");
		String address=sc.next();
		
		User u=new User();
		u.setName(name);
		u.setEmail(email);
		u.setPassword(pwd);
		u.setAddress(address);
		
		UserDao dao=new UserDao();
		dao.InsertUser(u);
		
		
			
		
	}

}
