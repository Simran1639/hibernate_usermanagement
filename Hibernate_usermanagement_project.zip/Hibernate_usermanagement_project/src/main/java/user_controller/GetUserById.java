package user_controller;

import java.util.Scanner;

import user_Dao.UserDao;
import user_Dto.User;

public class GetUserById {
	public static void main(String args[]) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter id...??????");
		int id=sc.nextInt();
		
		UserDao dao=new UserDao();
		User user=dao.getUserById(id);
		
		if(user!=null) {
			System.out.println("id="+user.getId()+"name="+user.getName()+"email="+user.getEmail()+"address="+user.getAddress());
		}else {
				System.out.println("id does not exist");
			}
		}
	
	}

