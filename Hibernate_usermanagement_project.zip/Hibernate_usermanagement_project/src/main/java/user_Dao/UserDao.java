package user_Dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import java.util.List;
import user_Dto.User;

public class UserDao {

	EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
	EntityManager manager=factory.createEntityManager();
	EntityTransaction et=manager.getTransaction();
	
	public void InsertUser(User user)
	{
		et.begin();
		manager.persist(user);
		et.commit();
	}
	
	public User getUserById(int id)
	{
		User user=manager.find(User.class, id);
		return user;
	}
	public List<User> getAllUsers()
	{
		Query q=manager.createQuery("select u from User u ",User.class);
		List<User> lt=q.getResultList();
		return lt;
	}
	
	public void deleteUser(int id)
	{
		User user=manager.find(User.class, id);
		if(user!=null)
		{
			et.begin();
			manager.remove(user);
			et.commit();
			
		}
		else
			System.out.println("id does not exist!!!!!!!!!!");
	}
		
		public void updateUser(User user)
		{
			et.begin();
			manager.merge(user);
			et.commit();
		}
		
		public List<User> getUserByEmailPwd(String email,int Pwd)
		{
			Query q=manager.createQuery("select u from User u where u.email=?1 and u.password=?2",User.class);
			q.setParameter(1, email);
			q.setParameter(2, Pwd);
			
			List<User> lt=q.getResultList();
			return lt;
			
		}
}
